
/**
 * This is the start class
 *
 * @author (Vidyoot Senthilvenkatesh)
 * @version (11/23/2021)
 */
public class Main {
    //This is the main/starter function
    public static void main(String[] args) {
        GUI begin = new GUI();
    }
}
