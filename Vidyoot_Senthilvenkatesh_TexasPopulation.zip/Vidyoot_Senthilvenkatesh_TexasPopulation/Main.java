import java.io.FileNotFoundException;
/**
 * This is the main method
 *
 * @author (Vidyoot Senthilvenkatesh)
 * @version (10/26/2021)
 */
public class Main
{
    public static void Main(String[] args) throws FileNotFoundException{
        new Population();
    }
}
